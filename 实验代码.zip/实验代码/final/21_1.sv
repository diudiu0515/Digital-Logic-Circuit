module light(
    input wire CLK,
    input wire RST,
    input wire KOBE,
    output reg [3:0] ew,
    output reg [3:0] ns,
    output reg rst_light,
    output reg red_light
    );
    
    reg CLK_1HZ;
    reg is_kobe;
    
    clock_divider div(
        .clk_1MHz(CLK),
        .rst(RST),
        .clk_1Hz(CLK_1HZ)
        );
    
    always_ff @(posedge CLK_1HZ or posedge RST) begin
        if (RST) begin
            if(KOBE==0) begin 
                ew <= 4'd3;
                ns <= 4'd3;
            end
        end
        else begin
            if (KOBE) begin
                is_kobe <= 1;
                ew <= 4'd8;
                ns <= 4'd8;
            end
            else begin
                is_kobe <= 0;
                case(ew)
                    4'd3:begin
                        ew<=4'd2;
                        ns<=4'd2;
                    end
                    4'd2:begin
                        ew<=4'd1;
                        ns<=4'd1;
                    end
                    4'd1:begin
                        ew<=4'd0;
                        ns<=4'd0;
                    end
                    4'd0:begin
                        ew<=4'd3;
                        ns<=4'd3;
                    end
                    4'd8:begin
                        ew<=4'd3;
                        ns<=4'd3;
                    end
                endcase
            end
        end
    end
    
    always_comb begin
        rst_light = RST;
        if (is_kobe) begin
            red_light = 1;
        end
        else begin
            if (ew == 4'd2 | ew == 4'd1 | ns==4'd2 | ns==4'd1) begin
                red_light = 1;
            end
            else begin
                red_light = 0;
            end
        end
    end
    
endmodule   


module clock_divider(
    input wire clk_1MHz,  // 输入1 MHz时钟
    input wire rst,       // 复位信号
    output reg clk_1Hz    // 输出1 Hz时钟
    );

    reg [19:0] counter;  // 20位计数器用于分频，使用20是因为2^20-1=1048575>1000000

    always_ff @(posedge clk_1MHz or posedge rst) begin // 1s内前0.5s先由低电平上升到高电平，后面0.5s再由高电平下降到低电平
        if (rst) begin
            counter <= 0;
            clk_1Hz <= 0;
        end else if (counter == 499_999) begin
            counter <= 0;
            clk_1Hz <= ~clk_1Hz;  // 翻转1 Hz时钟
        end else begin
            counter <= counter + 1;
        end
    end
endmodule