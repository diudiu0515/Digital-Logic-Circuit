module lift(
    input wire CLK,
    input wire RST,
    input wire direction,
    input wire KOBE,
    output reg [6:0] kobe
    );
    
    reg CLK_1hz;
    reg [3:0] dec;
    
    decoder Decoder(
        .sw(dec),
        .seg(kobe)
        );
    
    clock_divider div(
        .clk_1MHz(CLK),
        .rst(RST),
        .clk_1Hz(CLK_1hz)
        );
    
    typedef enum {one, two, three, four, five, six} state_t;
    
    state_t state;
    
    always_ff @(posedge CLK_1hz or posedge RST) begin
        if(RST) begin
            state <= one;
            dec <= 4'd1;
        end
        else begin
            case(state)
                one:begin
                    if(KOBE == 1) begin
                        dec <= dec;
                        state <= state;
                    end
                    else begin
                        if(direction == 1) begin
                            dec <= 4'd2;
                            state <= two;
                        end
                        else if(direction == 0) begin
                            dec <= 4'd1;
                            state <= one;
                        end
                    end
                end
                two:begin
                    if(KOBE == 1) begin
                        dec <= dec;
                        state <= state;
                    end
                    else begin
                        if(direction == 1) begin
                            dec <= 4'd3;
                            state <= three;
                        end
                        else if(direction == 0) begin
                            dec <= 4'd1;
                            state <= one;
                        end
                    end
                end
                three:begin
                    if(KOBE == 1) begin
                        dec <= dec;
                        state <= state;
                    end
                    else begin
                        if(direction == 1) begin
                            dec <= 4'd4;
                            state <= four;
                        end
                        else if(direction == 0) begin
                            dec <= 4'd2;
                            state <= two;
                        end
                    end
                end
                four:begin
                    if(KOBE == 1) begin
                        dec <= dec;
                        state <= state;
                    end
                    else begin
                        if(direction == 1) begin
                            dec <= 4'd5;
                            state <= five;
                        end
                        else if(direction == 0) begin
                            dec <= 4'd3;
                            state <= three;
                        end
                    end
                end
                five:begin
                    if(KOBE == 1) begin
                        dec <= dec;
                        state <= state;
                    end
                    else begin
                        if(direction == 1) begin
                            dec <= 4'd6;
                            state <= six;
                        end
                        else if(direction == 0) begin
                            dec <= 4'd4;
                            state <= four;
                        end
                    end
                end
                six:begin
                    if(KOBE == 1) begin
                        dec <= dec;
                        state <= state;
                    end
                    else begin
                        if(direction == 1) begin
                            dec <= 4'd6;
                            state <= six;
                        end
                        else if(direction == 0) begin
                            dec <= 4'd5;
                            state <= five;
                        end
                    end
                end
            endcase
        end
    end
        
    
endmodule

module clock_divider(
    input wire clk_1MHz,  // 输入1 MHz时钟
    input wire rst,       // 复位信号
    output reg clk_1Hz    // 输出1 Hz时钟
    );

    reg [19:0] counter;  // 20位计数器用于分频，使用20是因为2^20-1=1048575>1000000

    always_ff @(posedge clk_1MHz or posedge rst) begin // 1s内前0.5s先由低电平上升到高电平，后面0.5s再由高电平下降到低电平
        if (rst) begin
            counter <= 0;
            clk_1Hz <= 0;
        end else if (counter == 499_999) begin
            counter <= 0;
            clk_1Hz <= ~clk_1Hz;  // 翻转1 Hz时钟
        end else begin
            counter <= counter + 1;
        end
    end
endmodule

module decoder (
    input wire [3:0] sw,    //拨动开关输入
    output reg [6:0] seg    //七段数码管输出
    );

    always_comb begin      //组合逻辑块，一旦sw更新，seg会随之更新
        case (sw)          //4'hX: seg = 7'bYYYYYYY，其中4'h表示4位的十六进制值。比如4'h0代表十六进制的0，7个b代表7个LED灯，每个LED的状态是1（点亮）或0（熄灭）
            4'h0: seg = 7'b1111110;
            4'h1: seg = 7'b0110000;
            4'h2: seg = 7'b1101101;
            4'h3: seg = 7'b1111001;
            4'h4: seg = 7'b0110011;
            4'h5: seg = 7'b1011011;
            4'h6: seg = 7'b1011111;
            4'h7: seg = 7'b1110000;
            4'h8: seg = 7'b1111111;
            4'h9: seg = 7'b1110011;
            4'hA: seg = 7'b1110111;
            4'hB: seg = 7'b0011111;
            4'hC: seg = 7'b1001110;
            4'hD: seg = 7'b0111101;
            4'hE: seg = 7'b1001111;
            4'hF: seg = 7'b1000111;
            default: seg = 7'b0;  // 其余情况
        endcase
    end
endmodule