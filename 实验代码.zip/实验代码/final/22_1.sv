//my answer
module Final2023(
    input wire clk,
    input wire rst,
    input wire Ctrl, //拨码开关
    input wire Change, //手动换挡开关
    input wire Stop, //刹车开关
    output reg [3:0] Speed, //速度
    output reg [3:0] DW //挡位
    );
    wire clk_1Hz;
    
    clock_divider u_clk_div (
        .clk_1MHz(clk),
        .rst(rst),
        .clk_1Hz(clk_1Hz)
    );
    
    always_ff @(posedge clk_1Hz or posedge rst) begin
        if(rst)begin
            Speed <= 0;
            DW <= 1;
        end
        else begin
            if(Stop == 0)begin
                if(Ctrl == 1)begin //拨码开关为高电平，自动挡
                    if(Speed <9 && Speed != 1 && Speed != 3 && Speed != 5 && Speed != 7)begin
                        Speed ++;
                    end
                    else if (Speed == 1 || Speed == 3 || Speed == 5 || Speed == 7)begin
                        Speed ++;
                        DW ++;
                    end
                end
                else if(Ctrl == 0) begin //拨码开关为低电平，手动挡
                    if(Change) begin
                        if(Speed <9 && Speed != 1 && Speed != 3 && Speed != 5 && Speed != 7)begin
                            Speed ++;
                        end
                        else if (Speed == 1 || Speed == 3 || Speed == 5 || Speed == 7)begin
                            Speed ++;
                            DW ++;
                        end
                    end
                end
            end
            else if(Stop == 1)begin
                if(Speed >0 && Speed != 8 && Speed != 6 && Speed != 4 && Speed != 2)begin
                        Speed --;
                    end
                    else if (Speed == 8 || Speed == 6 || Speed == 4 || Speed == 2)begin
                        Speed --;
                        DW --;
                end
            end
        end
    end
endmodule

module clock_divider(
    input wire clk_1MHz,  // 输入1 MHz时钟
    input wire rst,       // 复位信号
    output reg clk_1Hz    // 输出1 Hz时钟
    );

    reg [19:0] counter;  // 20位计数器用于分频

    always_ff @(posedge clk_1MHz or posedge rst) begin
        if (rst) begin
            counter <= 0;
            clk_1Hz <= 0;
        end else if (counter == 499_999) begin
            counter <= 0;
            clk_1Hz <= ~clk_1Hz;  // 翻转1 Hz时钟
        end else begin
            counter <= counter + 1;
        end
    end
endmodule