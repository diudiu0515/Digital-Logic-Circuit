module mouse(
    input wire CLK,
    input wire RST,
    input wire open,
    input wire [3:0] hit,
    output reg [3:0] mouse,
    output reg [3:0] score
    );
    
    reg CLK_3s;
    reg [7:0] mid;
    reg hit_all;
    
    clock_divider div(
        .clk_1MHz(CLK),
        .rst(RST),
        .clk_3s(CLK_3s)
        );
        
    LFSR_random_generator gen(
        .clk(CLK_3s),
        .reset(RST),
        .random_out(mid)
        );
        
    always_ff @(posedge CLK_3s or posedge RST) begin
        if(RST) begin
            mouse <= 4'd0;
            score <= 4'd0;
            hit_all <= 0;
        end
        else begin
            if(open && hit_all && is_close) begin
                score <= score + 1;
            end
            
            mouse <= mid[7:4];
            
            hit_all <= (hit == mouse);  // 击中所有地鼠且未击中空洞
        end
    end
    
    
endmodule

module LFSR_random_generator( 
    input wire clk, 
    input wire reset, 
    output wire [7:0] random_out 
    );
    
    // LFSR的反馈多项式为 x^8 + x^6 + x^5 + x^4 + 1 
    reg [7:0] lfsr; 
    always_ff @(posedge clk or posedge reset) begin 
        if (reset) begin 
            // 当复位信号为高时，将LFSR重置 
            lfsr <= 8'b1; 
        end else begin 
            // 计算新的LFSR值 
            lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]}; 
        end 
    end 
    // 将LFSR的值输出作为随机数
    assign random_out = lfsr; 
    
endmodule

module clock_divider(
    input wire clk_1MHz,  // 输入1 MHz时钟
    input wire rst,       // 复位信号
    output reg clk_3s    // 输出5 Hz时钟
    );

    reg [25:0] counter;

    always_ff @(posedge clk_1MHz or posedge rst) begin
        if (rst) begin
            counter <= 0;
            clk_3s <= 0;
        end else if (counter == 1_499_999) begin
            counter <= 0;
            clk_3s <= ~clk_3s; 
        end else begin
            counter <= counter + 1;
        end
    end
endmodule