module guess(
    input wire CLK,
    input wire RST,
    input wire [2:0] guess,
    input wire open1,
    input wire open2,
    output reg low,
    output reg equal,
    output reg high,
    output reg [2:0] res
    );
    
    reg [7:0] mid;
    reg [2:0] kobe;
    reg is_kobe;
    reg CLK_10HZ;
    
    clock_divider div(
        .clk_1MHz(CLK),
        .rst(RST),
        .clk_10Hz(CLK_10HZ)
        );

        LFSR_random_generator gen(
            .clk(CLK_10HZ),
            .reset(RST),
            .random_out(mid)
            );    
    
    always_ff @(posedge CLK_10HZ or posedge RST) begin
        if(RST) begin
            res <= 3'd0;
            is_kobe <= 0;
            kobe[2:0] <= 3'd0;
        end
        else begin
            if(open1 && !open2) begin
                if(!is_kobe) begin
                    kobe[2:0] <= res[2:0];
                end
                is_kobe <= 1;
                res[2:0] <= 3'd7;
            end
            else if(open1 && open2) begin
                res[2:0] <= kobe[2:0];
            end
            else begin
                res[2:0] <= mid[2:0];
            end
        end
    end
    
    always_comb begin
        if(kobe < guess) begin
            low = 1;
            equal = 1;
            high = 1;
        end
        else if(kobe == guess) begin
            low = 1;
            equal = 1;
            high = 0;
        end
        else begin
            low = 1;
            equal = 0;
            high = 0;
        end
    end
    
endmodule

module LFSR_random_generator( 
    input wire clk, 
    input wire reset, 
    output wire [7:0] random_out 
    );
    
    // LFSR的反馈多项式为 x^8 + x^6 + x^5 + x^4 + 1 
    reg [7:0] lfsr; 
    always_ff @(posedge clk or posedge reset) begin 
        if (reset) begin 
            // 当复位信号为高时，将LFSR重置 
            lfsr <= 8'b1; 
        end else begin 
            // 计算新的LFSR值 
            lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]}; 
        end 
    end 
    // 将LFSR的值输出作为随机数
    assign random_out = lfsr; 
    
endmodule

module clock_divider(
    input wire clk_1MHz,  // 输入1 MHz时钟
    input wire rst,       // 复位信号
    output reg clk_10Hz    // 输出5 Hz时钟
    );

    reg [17:0] counter;

    always_ff @(posedge clk_1MHz or posedge rst) begin
        if (rst) begin
            counter <= 0;
            clk_10Hz <= 0;
        end else if (counter == 49_999) begin
            counter <= 0;
            clk_10Hz <= ~clk_10Hz; 
        end else begin
            counter <= counter + 1;
        end
    end
endmodule