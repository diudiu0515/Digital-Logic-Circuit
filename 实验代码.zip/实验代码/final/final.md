![](1.png)

![](2.png)

### decoder
```systemverilog
module Decoder (
    input wire [3:0] d,    //拨动开关输入
    output reg [6:0] seg    //七段数码管输出
    );

    always_comb begin
        case (d)
            4'd0: seg = 7'b1111110;
            4'd1: seg = 7'b0110000;
            4'd2: seg = 7'b1101101;
            4'd3: seg = 7'b1111001;
            4'd4: seg = 7'b0110011;
            4'd5: seg = 7'b1011011;
            4'd6: seg = 7'b1011111;
            4'd7: seg = 7'b1110000;
            4'd8: seg = 7'b1111111;
            4'd9: seg = 7'b1111011;
            4'd10: seg = 7'b1110111;
            4'd11: seg = 7'b0011111;
            4'd12: seg = 7'b1001110;
            4'd13: seg = 7'b0111101;
            4'd14: seg = 7'b1001111;
            4'd15: seg = 7'b1000111;
            default: seg = 7'b0;
        endcase
    end
endmodule
```

### always
过程块外面不能嵌套判断语句  

### 阻塞和非阻塞赋值
时序逻辑使用阻塞赋值，组合逻辑使用非阻塞赋值  
不允许在不同的always块中给同一个变量赋值，否则会产生冲突。  
同一个变量只能使用一个驱动源  

### 分频器
1Mhz时钟分频为1Hz时钟的代码如下：
```systemverilog
module clock_divider(
    input wire clk_1MHz,  // 输入1 MHz时钟
    input wire rst,       // 复位信号
    output reg clk_1Hz    // 输出1 Hz时钟
    );

    reg [19:0] counter;  // 20位计数器用于分频，使用20是因为2^20-1=1048575>1000000

    always_ff @(posedge clk_1MHz or posedge rst) begin // 1s内前0.5s先由低电平上升到高电平，后面0.5s再由高电平下降到低电平
        if (rst) begin
            counter <= 0;
            clk_1Hz <= 0;
        end else if (counter == 499_999) begin
            counter <= 0;
            clk_1Hz <= ~clk_1Hz;  // 翻转1 Hz时钟
        end else begin
            counter <= counter + 1;
        end
    end
endmodule
```
1KHz时钟分频为1Hz时钟的代码如下：
```systemverilog
module clock_divider(
    input wire clk_1KHz,  // 输入1 KHz时钟
    input wire rst,       // 复位信号
    output reg clk_1Hz    // 输出1 Hz时钟
    );

    reg [9:0] counter;  // 10位计数器用于分频，使用10是因为2^10-1=1023>1000

    always_ff @(posedge clk_1KHz or posedge rst) begin
        if (rst) begin
            counter <= 0;
            clk_1Hz <= 0;
        end else if (counter == 499) begin
            counter <= 0;
            clk_1Hz <= ~clk_1Hz;  // 翻转1 Hz时钟
        end else begin
            counter <= counter + 1;
        end
    end
```
### 状态机设计
- 使用三个always，一个用于现态转移，一个用于次态转移，一个用于输出逻辑
- 使用两个always，一个用来描述现态和次态之间的转移，另一个用来描述输出逻辑。
- 使用一个always来描述现次态转移和输出逻辑。
  
### 按下灯亮，松手灯灭
交给always_comb处理，或直接assign来处理

### 管脚绑定
```tcl
#CLK input
set_property -dict {PACKAGE_PIN J19 IOSTANDARD LVCMOS33} [get_ports CLK];     #CLK接插孔

#RST input
set_property -dict {PACKAGE_PIN K18 IOSTANDARD LVCMOS33} [get_ports RST];     #IO0接插孔


# required if touch button used as manual clock source
set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets CLK_IBUF]

set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
```