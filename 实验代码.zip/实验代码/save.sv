module my_final(
    input wire CLK,
    input wire RST,
    input wire open,//微动开关
    input wire [3:0] in,//拨码开关
    output reg led,//验证led
    output reg [3:0] res,//输出led
    output reg [3:0] num_one//译码器
    );
    
    reg CLK_2S;
    reg [7:0] mid;
    reg [3:0] memory;
    shortint last_open;

    clock_divider div(
        .clk_1MHz(CLK),
        .rst(RST),
        .clk_2s(CLK_2S)
        );

    LFSR_random_generator gen(
        .clk(CLK_2S),
        .reset(RST),
        .random_out(mid)
        );
        
    always_ff @(posedge CLK_2S or posedge RST) begin
        if(RST) begin
            res <= 4'd0;
            last_open <= 0;
            memory <= 4'd0;
        end
        else begin
            if(open && !last_open) begin
                res <= memory;   
            end else begin
                if(!open) begin
                    res[3:0]=mid[7:4];
                    memory[3:0]=res[3:0];
                    last_open=0;
                end else begin 
                    res <= 4'd0;
                end
            end
        end
    end
    always_comb begin
        led = 0;
        sum = (memory[3]==in[3])+(memory[2]==in[2])+(memory[1]==in[1])+(memory[1]==in[1])+(memory[0]==in[0])
        if(sum == 4) begin
           led = 1;
           num_one = 4'd0;
        end
        else begin
            led = 0;
            num_one = 4 - sum;
        end
    end
endmodule


module LFSR_random_generator( 
    input wire clk, 
    input wire reset, 
    output wire [7:0] random_out 
    );
    
    // LFSR的反馈多项式为 x^8 + x^6 + x^5 + x^4 + 1 
    reg [7:0] lfsr; 
    always_ff @(posedge clk or posedge reset) begin 
        if (reset) begin 
            // 当复位信号为高时，将LFSR重置 
            lfsr <= 8'b1; 
        end else begin 
            // 计算新的LFSR值 
            lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]}; 
        end 
    end 
    // 将LFSR的值输出作为随机数
    assign random_out = lfsr; 
    
endmodule

module clock_divider(
    input wire clk_1MHz,  // 输入1 MHz时钟
    input wire rst,       // 复位信号
    output reg clk_2s    // 输出5 Hz时钟
    );

    reg [25:0] counter;

    always_ff @(posedge clk_1MHz or posedge rst) begin
        if (rst) begin
            counter <= 0;
            clk_2s <= 0;
        end else if (counter == 249_999) begin
            counter <= 0;
            clk_2s <= ~clk_2s; 
        end else begin
            counter <= counter + 1;
        end
    end
endmodule