module topadd(
    input  logic [3:0] A,
    input  logic [3:0] B,
    input  logic       Cin,

    output logic [3:0] seg_l,
    output logic [3:0] seg_h,
    output logic       Cout
);

logic [4:0] sum;

always_comb begin

    sum = A + B + Cin;

    if(sum < 10)
    begin
        seg_h = 0;
        seg_l = sum;
    end

    else if(sum < 20)
    begin
        seg_h = 1;
        seg_l = sum - 10;
    end

    else if(sum < 30)
    begin
        seg_h = 2;
        seg_l = sum - 20;
    end

    else
    begin
        seg_h = 3;
        seg_l = sum - 30;
    end

    Cout = sum[4];

end

endmodule