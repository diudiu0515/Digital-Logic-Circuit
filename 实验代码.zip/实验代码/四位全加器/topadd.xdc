# --- A 输入 (IO1 - IO4) ---
set_property -dict {PACKAGE_PIN M21 IOSTANDARD LVCMOS33} [get_ports {A[3]}]; #IO1
set_property -dict {PACKAGE_PIN N20 IOSTANDARD LVCMOS33} [get_ports {A[2]}]; #IO2
set_property -dict {PACKAGE_PIN N22 IOSTANDARD LVCMOS33} [get_ports {A[1]}]; #IO3
set_property -dict {PACKAGE_PIN P21 IOSTANDARD LVCMOS33} [get_ports {A[0]}]; #IO4

# --- B 输入 (IO6 - IO9) ---
set_property -dict {PACKAGE_PIN T21 IOSTANDARD LVCMOS33} [get_ports {B[3]}]; #IO6
set_property -dict {PACKAGE_PIN U21 IOSTANDARD LVCMOS33} [get_ports {B[2]}]; #IO7
set_property -dict {PACKAGE_PIN R21 IOSTANDARD LVCMOS33} [get_ports {B[1]}]; #IO8
set_property -dict {PACKAGE_PIN R22 IOSTANDARD LVCMOS33} [get_ports {B[0]}]; #IO9

# --- Cin 输入 (IO5) ---
set_property -dict {PACKAGE_PIN P22 IOSTANDARD LVCMOS33} [get_ports Cin];     #IO5

# --- 个位 BCD 输出 (IO17 - IO20) -> 接数码管1 ---
set_property -dict {PACKAGE_PIN AB18 IOSTANDARD LVCMOS33} [get_ports {seg_l[3]}]; #IO17
set_property -dict {PACKAGE_PIN AA20 IOSTANDARD LVCMOS33} [get_ports {seg_l[2]}]; #IO18
set_property -dict {PACKAGE_PIN AB21 IOSTANDARD LVCMOS33} [get_ports {seg_l[1]}]; #IO19
set_property -dict {PACKAGE_PIN AA21 IOSTANDARD LVCMOS33} [get_ports {seg_l[0]}]; #IO20

# --- 十位 BCD 输出 (IO11 - IO14) -> 接数码管2 ---
set_property -dict {PACKAGE_PIN W21 IOSTANDARD LVCMOS33} [get_ports {seg_h[3]}]; #IO11
set_property -dict {PACKAGE_PIN W22 IOSTANDARD LVCMOS33} [get_ports {seg_h[2]}]; #IO12
set_property -dict {PACKAGE_PIN Y22 IOSTANDARD LVCMOS33} [get_ports {seg_h[1]}]; #IO13
set_property -dict {PACKAGE_PIN Y21 IOSTANDARD LVCMOS33} [get_ports {seg_h[0]}]; #IO14

# --- Cout 进位输出 (IO16) -> 接 LED ---
set_property -dict {PACKAGE_PIN AA18 IOSTANDARD LVCMOS33} [get_ports Cout];     #IO16

# 电压配置
set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]