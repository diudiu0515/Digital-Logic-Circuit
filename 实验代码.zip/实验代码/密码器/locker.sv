module Locker(
    input  wire [3:0] Code,
    input  wire Mode,      // 0: 设置密码；1: 验证密码
    input  wire CLK,
    input  wire RST,
    output reg  Unlock,
    output reg  Err,
    output reg  Alert
);

    reg [15:0] user_password;
    reg [15:0] input_token;
    reg [1:0] count;
    reg [2:0] wrong_times;

    localparam [15:0] DEFAULT_PASSWORD = 16'h1234;
    localparam [15:0] ADMIN_PASSWORD   = 16'h0501;

    always_ff @(posedge CLK or posedge RST) begin
        if (RST) begin
            user_password <= DEFAULT_PASSWORD;
            input_token   <= 16'h0000;
            count         <= 2'd0;
            wrong_times   <= 3'd0;
            Unlock        <= 1'b0;
            Err           <= 1'b0;
            Alert         <= 1'b0;
        end
        else begin
            Unlock <= 1'b0;
            Err    <= 1'b0;

            case (count)
                2'd0: input_token[15:12] <= Code;
                2'd1: input_token[11:8]  <= Code;
                2'd2: input_token[7:4]   <= Code;
                2'd3: begin
                    input_token[3:0] <= Code;

                    if (Mode == 1'b0 && Alert == 1'b0) begin
                        user_password <= {input_token[15:4], Code};
                    end
                    else begin
                        if (Alert == 1'b1) begin
                            if ({input_token[15:4], Code} == ADMIN_PASSWORD) begin
                                Unlock <= 1'b1;
                                Alert  <= 1'b0;
                                wrong_times <= 3'd0;
                            end
                            else begin
                                Err <= 1'b1;
                            end
                        end
                        else begin
                            if (({input_token[15:4], Code} == user_password) ||
                                ({input_token[15:4], Code} == ADMIN_PASSWORD)) begin
                                Unlock <= 1'b1;
                                wrong_times <= 3'd0;
                            end
                            else begin
                                Err <= 1'b1;
                                if (wrong_times == 3'd2) begin
                                    Alert <= 1'b1;
                                    wrong_times <= 3'd3;
                                end
                                else begin
                                    wrong_times <= wrong_times + 1'b1;
                                end
                            end
                        end
                    end
                end
            endcase

            if (count == 2'd3)
                count <= 2'd0;
            else
                count <= count + 1'b1;
        end
    end

endmodule

16	这个数总共有 16 位 bit
'h	后面的数字按十六进制解释
1234	十六进制数值