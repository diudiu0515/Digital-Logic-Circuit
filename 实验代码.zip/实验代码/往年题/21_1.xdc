# CLK input
set_property -dict {PACKAGE_PIN J19 IOSTANDARD LVCMOS33} [get_ports CLK] 

# RST input
set_property -dict {PACKAGE_PIN K18 IOSTANDARD LVCMOS33} [get_ports RST] 

# Mode input
set_property -dict {PACKAGE_PIN W21 IOSTANDARD LVCMOS33} [get_ports open]

set_property -dict {PACKAGE_PIN AA18 IOSTANDARD LVCMOS33} [get_ports led_red];

set_property -dict {PACKAGE_PIN AB18 IOSTANDARD LVCMOS33} [get_ports {rst_light}]

set_property -dict {PACKAGE_PIN M21 IOSTANDARD LVCMOS33} [get_ports {one[3]}]; 
set_property -dict {PACKAGE_PIN N20 IOSTANDARD LVCMOS33} [get_ports {one[2]}]; 
set_property -dict {PACKAGE_PIN N22 IOSTANDARD LVCMOS33} [get_ports {one[1]}]; 
set_property -dict {PACKAGE_PIN P21 IOSTANDARD LVCMOS33} [get_ports {one[0]}]; 

set_property -dict {PACKAGE_PIN T21 IOSTANDARD LVCMOS33} [get_ports {two[3]}]; 
set_property -dict {PACKAGE_PIN U21 IOSTANDARD LVCMOS33} [get_ports {two[2]}]; 
set_property -dict {PACKAGE_PIN R21 IOSTANDARD LVCMOS33} [get_ports {two[1]}]; 
set_property -dict {PACKAGE_PIN R22 IOSTANDARD LVCMOS33} [get_ports {two[0]}]; 


set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets CLK_IBUF]

# 电压配置
set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
