module my_final(
    input wire CLK,
    input wire RST,
    input wire open,
    input wire em,
    output reg [6:0] res
    );
    
    reg CLK_1S;
    reg [3:0] cnt;
    
    clock_divider div(
        .clk_1MHz(CLK),
        .rst(RST),
        .clk_1s(CLK_1S)
        );

    Decoder decoder(
        .d(cnt),
        .seg(res)
        );

    always_ff @(posedge CLK_1S or posedge RST) begin
        if(RST) begin
            cnt <= 4'd1;
        end else begin
            if(em) begin
                cnt <= cnt;
            end else begin 
                if(open) begin
                    if(cnt == 4'd6) begin
                        cnt <= cnt;
                    end else begin 
                        cnt <= cnt + 1;
                    end
                end else begin 
                    if(cnt <= 4'd1) begin
                        cnt <= cnt;
                    end else begin 
                        cnt <= cnt - 1;
                    end
                end
            end
        end
    end
endmodule

module clock_divider(
    input wire clk_1MHz,  // 输入1 MHz时钟
    input wire rst,       // 复位信号
    output reg clk_1s    
    );

    reg [25:0] counter;

    always_ff @(posedge clk_1MHz or posedge rst) begin
        if (rst) begin
            counter <= 0;
            clk_1s <= 0;
        end else if (counter == 499_999) begin
            counter <= 0;
            clk_1s <= ~clk_1s; 
        end else begin
            counter <= counter + 1;
        end
    end
endmodule

module Decoder (
    input  wire [3:0] d,
    output reg  [6:0] seg
);

    always_comb begin
        case (d)
            4'd0: seg = 7'b1111110;
            4'd1: seg = 7'b0110000;
            4'd2: seg = 7'b1101101;
            4'd3: seg = 7'b1111001;
            4'd4: seg = 7'b0110011;
            4'd5: seg = 7'b1011011;
            4'd6: seg = 7'b1011111;
            4'd7: seg = 7'b1110000;
            4'd8: seg = 7'b1111111;
            4'd9: seg = 7'b1111011;
            default: seg = 7'b0000000;
        endcase
    end

endmodule
