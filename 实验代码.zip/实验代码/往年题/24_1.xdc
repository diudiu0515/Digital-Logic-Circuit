# CLK input
set_property -dict {PACKAGE_PIN J19 IOSTANDARD LVCMOS33} [get_ports CLK] 

# RST input
set_property -dict {PACKAGE_PIN K18 IOSTANDARD LVCMOS33} [get_ports RST] 

set_property -dict {PACKAGE_PIN W21 IOSTANDARD LVCMOS33} [get_ports open] 

set_property -dict {PACKAGE_PIN AA18 IOSTANDARD LVCMOS33} [get_ports record] 

set_property -dict {PACKAGE_PIN M21 IOSTANDARD LVCMOS33} [get_ports {hit[3]}]; 
set_property -dict {PACKAGE_PIN N20 IOSTANDARD LVCMOS33} [get_ports {hit[2]}]; 
set_property -dict {PACKAGE_PIN N22 IOSTANDARD LVCMOS33} [get_ports {hit[1]}]; 
set_property -dict {PACKAGE_PIN P21 IOSTANDARD LVCMOS33} [get_ports {hit[0]}]; 

set_property -dict {PACKAGE_PIN T21 IOSTANDARD LVCMOS33} [get_ports {mouse[3]}]; 
set_property -dict {PACKAGE_PIN U21 IOSTANDARD LVCMOS33} [get_ports {mouse[2]}]; 
set_property -dict {PACKAGE_PIN R21 IOSTANDARD LVCMOS33} [get_ports {mouse[1]}]; 
set_property -dict {PACKAGE_PIN R22 IOSTANDARD LVCMOS33} [get_ports {mouse[0]}]; 

set_property -dict {PACKAGE_PIN AB18 IOSTANDARD LVCMOS33} [get_ports {score[3]}]; 
set_property -dict {PACKAGE_PIN AA20 IOSTANDARD LVCMOS33} [get_ports {score[2]}]; 
set_property -dict {PACKAGE_PIN AB21 IOSTANDARD LVCMOS33} [get_ports {score[1]}]; 
set_property -dict {PACKAGE_PIN AA21 IOSTANDARD LVCMOS33} [get_ports {score[0]}]; 

set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets CLK_IBUF]

# 电压配置
set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
