module my_final(
    input wire CLK,
    input wire RST,
    input wire open,
    output reg [7:0] led
    );
    
    reg CLK_5HZ;
    reg [7:0] mid;
    reg last_open;
    shortint opentimes;
    
    clock_divider div(
        .clk_1MHz(CLK),
        .rst(RST),
        .clk_5Hz(CLK_5HZ)
        );

    LFSR_random_generator gen(
        .clk(CLK_5HZ),
        .reset(RST),
        .random_out(mid)
        );
        
    always_ff @(posedge CLK_5HZ or posedge RST) begin
            if(RST) begin
                led <= 8'd0;
                open_times <= 0;
                last_open <= 0;
            end
            else begin
                if(open && !last_open) begin 
                    case(open_times)
                        0:begin
                            led[5:0] <= mid[5:0];
                            open_times <= 1;
                        end
                        1:begin
                            led[5:2] <= mid[5:2];
                            open_times <= 2;
                        end
                        2:begin
                            led[5:4] <= mid[5:4];
                            open_times <= 3;
                        end
                    endcase
                    last_open <= open;
                end
                else begin
                    case(open_times)
                        0:begin
                            led[5:0] <= mid[5:0];
                        end
                        1:begin
                            led[5:2] <= mid[5:2];
                        end
                        2:begin
                            led[5:4] <= mid[5:4];
                        end
                        3:begin
                            led <= led;
                        end
                        endcase
                    last_open <=open;
                end
            end
    end
    
endmodule



module LFSR_random_generator( 
    input wire clk, 
    input wire reset, 
    output wire [7:0] random_out 
    ); 
 
// LFSR的反馈多项式为 x^8 + x^6 + x^5 + x^4 + 1 
    reg [7:0] lfsr; 
    always_ff @(posedge clk or posedge reset) begin 
        if (reset) begin 
            // 当复位信号为高时，将LFSR重置 
            lfsr <= 8'b1; 
        end else begin 
            // 计算新的LFSR值 
            lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]}; 
        end 
    end 
 
// 将LFSR的值输出作为随机数
assign random_out = lfsr; 
 
endmodule

module clock_divider(
    input  wire clk_1MHz,
    input  wire rst,
    output reg  clk_5Hz
);

    reg [19:0] counter;

    always_ff @(posedge clk_1MHz or negedge rst) begin
        if (rst) begin
            counter <= 20'd0;
            clk_5Hz <= 1'b0;
        end else if (counter == 20'd99_999) begin
            counter <= 20'd0;
            clk_5Hz <= ~clk_5Hz;
        end else begin
            counter <= counter + 20'd1;
        end
    end

endmodule