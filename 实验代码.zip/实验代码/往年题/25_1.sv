module my_final(
    input  wire CLK,
    input  wire RST,
    input  wire switch,//暂停时选择显示当前序列还是历史序列
    input  wire record, //0表示正常随机刷新，1表示暂停/查看历史
    output reg [7:0] res,
    output reg [3:0] num_one
    );

    reg CLK_2S;
    reg [7:0] mid;
    reg [7:0] res_history;
    reg [7:0] current;

    clock_divider div(
        .clk_1MHz(CLK),
        .rst(RST),
        .clk_2s(CLK_2S)
        );

    LFSR_random_generator generator( 
        .clk(CLK_2S),
        .reset(RST),
        .random_out(mid)
    ); 

    always_ff @(posedge CLK_2S or posedge RST) begin
        if(RST) begin
            res <= 8'd0;
            current <= 8'd0;
            res_history <= 8'd0;
        end else begin
            if(!record) begin 
                if(res[0]+res[1]+res[2]+res[3]+res[4]+res[5]+res[6]+res[7] >=4) begin
                    res_history <= res;
            end
                res <= mid;
                current <= mid;
            end else begin
                if(switch) begin 
                    res <= res_history;
                end else begin
                    res <= current;
                end
            end
         end
     end       
     
    always_comb begin
        if(res[0]+res[1]+res[2]+res[3]+res[4]+res[5]+res[6]+res[7] >=4) begin
            num_one = 4'd1;
        end else begin
            num_one = 4'd0;
        end
    end

endmodule

module LFSR_random_generator( 
    input wire clk, 
    input wire reset, 
    output wire [7:0] random_out
    ); 
 
// LFSR的反馈多项式为 x^8 + x^6 + x^5 + x^4 + 1 
    reg [7:0] lfsr; 
    always_ff @(posedge clk or posedge reset) begin 
        if (reset) begin 
            // 当复位信号为高时，将LFSR重置 
            lfsr <= 8'b1; 
        end else begin 
            // 计算新的LFSR值 
            lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]}; 
        end 
    end 
 
// 将LFSR的值输出作为随机数
assign random_out = lfsr; 
 
endmodule

module clock_divider(
    input  wire clk_1MHz,
    input  wire rst,
    output reg  clk_2s
);

    reg [19:0] counter;

    always_ff @(posedge clk_1MHz or posedge rst) begin
        if (rst) begin
            counter <= 20'd0;
            clk_2s <= 1'b0;
        end else if (counter == 20'd999_999) begin
            counter <= 20'd0;
            clk_2s <= ~clk_2s;
        end else begin
            counter <= counter + 20'd1;
        end
    end

endmodule
