# CLK input
set_property -dict {PACKAGE_PIN J19 IOSTANDARD LVCMOS33} [get_ports CLK] #CLK

# RST input
set_property -dict {PACKAGE_PIN K18 IOSTANDARD LVCMOS33} [get_ports RST] #IO0

# Mode input
set_property -dict {PACKAGE_PIN W21 IOSTANDARD LVCMOS33} [get_ports switch] #IO11

set_property -dict {PACKAGE_PIN AA18 IOSTANDARD LVCMOS33} [get_ports record] #IO16

set_property -dict {PACKAGE_PIN M21 IOSTANDARD LVCMOS33} [get_ports {res[7]}]; #IO1
set_property -dict {PACKAGE_PIN N20 IOSTANDARD LVCMOS33} [get_ports {res[6]}]; #IO2
set_property -dict {PACKAGE_PIN N22 IOSTANDARD LVCMOS33} [get_ports {res[5]}]; #IO3
set_property -dict {PACKAGE_PIN P21 IOSTANDARD LVCMOS33} [get_ports {res[4]}]; #IO4
set_property -dict {PACKAGE_PIN T21 IOSTANDARD LVCMOS33} [get_ports {res[3]}]; #IO6
set_property -dict {PACKAGE_PIN U21 IOSTANDARD LVCMOS33} [get_ports {res[2]}]; #IO7
set_property -dict {PACKAGE_PIN R21 IOSTANDARD LVCMOS33} [get_ports {res[1]}]; #IO8
set_property -dict {PACKAGE_PIN R22 IOSTANDARD LVCMOS33} [get_ports {res[0]}]; #IO9

set_property -dict {PACKAGE_PIN AB18 IOSTANDARD LVCMOS33} [get_ports {num_one[3]}]; #IO17
set_property -dict {PACKAGE_PIN AA20 IOSTANDARD LVCMOS33} [get_ports {num_one[2]}]; #IO18
set_property -dict {PACKAGE_PIN AB21 IOSTANDARD LVCMOS33} [get_ports {num_one[1]}]; #IO19
set_property -dict {PACKAGE_PIN AA21 IOSTANDARD LVCMOS33} [get_ports {num_one[0]}]; #IO20

set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets CLK_IBUF]

# 电压配置
set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
