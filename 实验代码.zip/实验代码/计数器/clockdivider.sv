clockdivider.sv   分频器：把 1MHz 时钟变成 1Hz
clockstart.sv     主计数器：00 到 59 计数，可启动/暂停
decoder.sv        七段数码管译码器：把数字 0-9 变成数码管灯信号

module clock_divider(
    input  wire clk_1MHz,
    input  wire rst,
    output reg  clk_1Hz
);

    reg [19:0] counter;

    always_ff @(posedge clk_1MHz or negedge rst) begin
        if (rst) begin
            counter <= 20'd0;
            clk_1Hz <= 1'b0;
        end else if (counter == 20'd499_999) begin
            counter <= 20'd0;
            clk_1Hz <= ~clk_1Hz;
        end else begin
            counter <= counter + 20'd1;
        end
    end

endmodule

1Hz：499_999
2 秒周期：999_999
3 秒周期：1_499_999
5Hz：99_999
10Hz：49_999