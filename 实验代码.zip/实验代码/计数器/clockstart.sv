module clockstart(
    input  wire CLK,      // 1MHz 时钟输入
    input  wire RST,      // 低电平复位
    input  wire Start,    // 启动/暂停开关，1运行，0暂停
    output wire [6:0] High,
    output wire [6:0] Low
);

    reg [3:0] cnt_H;
    reg [3:0] cnt_L;

    wire clk_1Hz;

    clock_divider u_clk_div (
        .clk_1MHz(CLK),
        .rst(RST),
        .clk_1Hz(clk_1Hz)
    );

    always_ff @(posedge clk_1Hz or negedge RST) begin
        if (!RST) begin
            cnt_H <= 4'd0;
            cnt_L <= 4'd0;
        end else if (Start) begin
            if (cnt_L == 4'd9) begin
                cnt_L <= 4'd0;

                if (cnt_H == 4'd5) begin
                    cnt_H <= 4'd0;
                end else begin
                    cnt_H <= cnt_H + 4'd1;
                end
            end else begin
                cnt_L <= cnt_L + 4'd1;
            end
        end
    end

    Decoder u1 (
        .d   (cnt_H),
        .seg (High)
    );

    Decoder u2 (
        .d   (cnt_L),
        .seg (Low)
    );

endmodule