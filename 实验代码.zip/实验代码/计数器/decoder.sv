module Decoder (
    input  wire [3:0] d,
    output reg  [6:0] seg
);

    always_comb begin
        case (d)
            4'd0: seg = 7'b1111110;
            4'd1: seg = 7'b0110000;
            4'd2: seg = 7'b1101101;
            4'd3: seg = 7'b1111001;
            4'd4: seg = 7'b0110011;
            4'd5: seg = 7'b1011011;
            4'd6: seg = 7'b1011111;
            4'd7: seg = 7'b1110000;
            4'd8: seg = 7'b1111111;
            4'd9: seg = 7'b1111011;
            default: seg = 7'b0000000;
        endcase
    end

endmodule

seg[6] -> A
seg[5] -> B
seg[4] -> C
seg[3] -> D
seg[2] -> E
seg[1] -> F
seg[0] -> G

| 位      | 权值 |
| ------ | -- |
| reg[3] | 8  |
| reg[2] | 4  |
| reg[1] | 2  |
| reg[0] | 1  |


4   -> 用4位表示
d   -> 十进制(decimal)
5   -> 数值5